from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MobilePhoneViewSet

# Create a router and register the MobilePhoneViewSet
router = DefaultRouter()
router.register(r'mobiles', MobilePhoneViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
