from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import MobilePhone
from .serializers import MobilePhoneSerializer

class MobilePhoneViewSet(viewsets.ModelViewSet):
    queryset = MobilePhone.objects.all()
    serializer_class = MobilePhoneSerializer

    # Create a new mobile phone
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    # Read (Retrieve) a single mobile phone
    def retrieve(self, request, pk=None, *args, **kwargs):
        phone = self.get_object()
        serializer = self.get_serializer(phone)
        return Response(serializer.data)

    # Read (List) all mobile phones
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    # Update an existing mobile phone
    def update(self, request, pk=None, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    # Delete a mobile phone
    def destroy(self, request, pk=None, *args, **kwargs):
        phone = self.get_object()
        phone.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    # Partial update (patch)
    def partial_update(self, request, pk=None, *args, **kwargs):
        return self.update(request, pk, partial=True)

    # Custom action for additional functionality
    @action(detail=False, methods=['get'])
    def custom_action(self, request):
        # Add custom functionality here, if needed
        return Response({'status': 'Custom action!'})
