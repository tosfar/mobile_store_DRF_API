from rest_framework import serializers
from .models import MobilePhone

class MobilePhoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = MobilePhone
        fields = '__all__'
